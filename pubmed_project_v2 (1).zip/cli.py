import argparse
from pubmed_fetcher.fetcher import fetch_filtered_papers, save_to_csv

def main():
    parser = argparse.ArgumentParser(description="Fetch PubMed papers with pharma/biotech authors.")
    parser.add_argument("query", help="Search query for PubMed")
    parser.add_argument("-f", "--file", help="Output CSV filename")
    parser.add_argument("-d", "--debug", action="store_true", help="Enable debug logging")
    args = parser.parse_args()

    results = fetch_filtered_papers(args.query, debug=args.debug)
    if args.file:
        save_to_csv(results, args.file)
        print(f"Saved to {args.file}")
    else:
        for r in results:
            print(r)

if __name__ == "__main__":
    main()