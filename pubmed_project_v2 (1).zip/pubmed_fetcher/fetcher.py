from typing import List, Dict
from Bio import Entrez
import pandas as pd
import re
import logging

Entrez.email = "your_email@example.com"  # Replace with your actual email

# Heuristic keywords
ACADEMIC_KEYWORDS = ["university", "college", "institute", "school", "department", "centre"]
NON_ACADEMIC_HINTS = ["pharma", "biotech", "inc", "ltd", "llc", "corp"]

def search_pubmed(query: str, max_results: int = 50) -> List[str]:
    handle = Entrez.esearch(db="pubmed", term=query, retmax=max_results)
    record = Entrez.read(handle)
    return record["IdList"]

def fetch_details(pubmed_ids: List[str]) -> List[Dict]:
    handle = Entrez.efetch(db="pubmed", id=pubmed_ids, rettype="medline", retmode="text")
    from Bio import Medline
    records = Medline.parse(handle)
    return list(records)

def is_non_academic(affiliation: str) -> bool:
    aff_lower = affiliation.lower()
    return (
        not any(word in aff_lower for word in ACADEMIC_KEYWORDS)
        and any(word in aff_lower for word in NON_ACADEMIC_HINTS)
    )

def extract_info(record: Dict) -> Dict:
    title = record.get("TI", "")
    pubmed_id = record.get("PMID", "")
    pub_date = record.get("DP", "")
    authors = record.get("FAU", [])
    affiliations = record.get("AD", [])
    emails = re.findall(r"[\w\.-]+@[\w\.-]+", str(affiliations))

    if isinstance(affiliations, str):
        affiliations = [affiliations]

    non_academic_authors = []
    companies = []
    for author, aff in zip(authors, affiliations):
        if is_non_academic(aff):
            non_academic_authors.append(author)
            companies.append(aff)

    return {
        "PubmedID": pubmed_id,
        "Title": title,
        "Publication Date": pub_date,
        "Non-academic Author(s)": "; ".join(non_academic_authors),
        "Company Affiliation(s)": "; ".join(companies),
        "Corresponding Author Email": emails[0] if emails else "",
    }

def fetch_filtered_papers(query: str, debug: bool = False) -> List[Dict]:
    if debug:
        logging.basicConfig(level=logging.DEBUG)
    ids = search_pubmed(query)
    logging.debug(f"Found IDs: {ids}")
    records = fetch_details(ids)
    results = []
    for record in records:
        info = extract_info(record)
        if info["Non-academic Author(s)"]:
            results.append(info)
    return results

def save_to_csv(results: List[Dict], filename: str):
    df = pd.DataFrame(results)
    df.to_csv(filename, index=False)